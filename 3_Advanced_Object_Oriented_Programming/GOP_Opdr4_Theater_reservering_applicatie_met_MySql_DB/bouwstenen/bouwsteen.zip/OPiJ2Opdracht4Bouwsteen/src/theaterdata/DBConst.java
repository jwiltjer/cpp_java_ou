package theaterdata;

/**
 * Deze klasse bevat de constanten die gebruikt worden om verbinding
 * te maken met de database.
 */
public class DBConst {
  protected static final String DRIVERNAAM = "com.mysql.jdbc.Driver";
  protected static final String URL = "jdbc:mysql://localhost/theater";
  protected static final String GEBRUIKERSNAAM = "cppjava";
  protected static final String WACHTWOORD = "theater"; 
}
